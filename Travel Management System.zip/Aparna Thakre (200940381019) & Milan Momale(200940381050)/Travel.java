package Project;
import java.text.DecimalFormat;
import java.util.Scanner;

public class Travel 
{
      private static DecimalFormat df2 = new DecimalFormat(".##");
      public static void main(String[] args)
      {
         int i,count;
         double GST_cal = 0;
         double total_package=0,rate=0,GST=0;  
         Bookpackage[] B= new Bookpackage[10];
         for(i=0; i<B.length; i++)
         {
             B[i]=new Bookpackage();
         }

         Billing[] bill=new Billing[10];
         for(i=0; i<bill.length; i++)
         {
             bill[i]=new Billing();
         }
         Scanner inp=new Scanner(System.in);
         Packagedetails P = new Packagedetails();
      
        int choice;     
        exit:
      while(true)
      {
          System.out.println("Welcome to the Travel Agency.........\nHope you enjoy journey with us!!!");
          System.out.println("***************");
          System.out.println("Enter your choice:");
          System.out.println(" 1.View tour package details.\n 2.Book a package.\n 3.View Round Trip Distance\n 4.Exit");
          choice=inp.nextInt();
          switch(choice)
          {
              
              case 1: 
                {
                P.details();
                P.travelMode();
                break;
                }
           
               case 2:  
                    {
                        //taken for only one customer
                        count=1;
                        for(i=0;i<count;i++)
                        {
                            total_package=B[i].customerDetails();
                            GST_cal = bill[i].GST_calculate(total_package,rate,GST);
                            System.out.println("The GST amount = "+df2.format(GST_cal));
                        }
                        break;
                        
                     }
               
               case 3: 
                    System.out.println("Enter the start city : 1.Manali\n 2.Andaman \n 3.Goa \n 4.Ooty \n 5.Ladakh");
                    Scanner sc= new Scanner(System.in);
                    int ch=sc.nextInt();
                    GFG ac=new GFG();
                    int n = 5; 
  
                    int[][] graph =
                         {{0, 2773, 2508, 2996,473}, 
                         {2773, 0, 2040, 1738,4556}, 
                         {2508, 2040, 0, 764,3033}, 
                         {2996, 1738, 764, 0,3456},
                         {473,4556,3033,3456,0}}; 
                    boolean[] v = new boolean[n]; 
                    v[0] = true; 
                    int ans = Integer.MAX_VALUE; 
                    int an = Integer.MAX_VALUE;
                    int a = Integer.MAX_VALUE;
                    int ab = Integer.MAX_VALUE;
                    int ax = Integer.MAX_VALUE;

       
     switch(ch)
     {
         case 1:    ans = ac.tsp(graph, v, 0, n, 1, 0, ans); 
                    System.out.println(ans+" Kms"); 
                    break;
         case 2:    an = ac.tsp(graph, v, 1, n, 1, 0, an); 
                    System.out.println(an+" Kms"); 
                    break;
         case 3:    a = ac.tsp(graph, v, 2, n, 1, 0, a); 
                    System.out.println(a+" Kms"); 
                    break;
         case 4:    ab = ac.tsp(graph, v, 3, n, 1, 0, ab); 
                    System.out.println(ab+" Kms"); 
                    break;
         case 5:    ax = ac.tsp(graph, v, 4, n, 1, 0, ax);
                    System.out.println(ax+" Kms"); 
                    break;
         default: System.out.println("Invalid choice of city");
    
    }
               break;

               
               
               case 4: 
                   break exit;
          
               
              default:System.out.println("Invalid choice entered!!!!");
              
          }
      }
    }
}