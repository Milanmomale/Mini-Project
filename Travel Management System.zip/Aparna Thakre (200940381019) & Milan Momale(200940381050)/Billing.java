package Project;
import java.text.DecimalFormat;


public class Billing
{
    private static DecimalFormat df2 = new DecimalFormat(".##");
    
   
    public double GST_calculate(double total_package,double rate,double GST)
    {
        System.out.println("The total_amt = " +df2.format(total_package));
        
        GST=(total_package*18)/100;
        rate=total_package+GST;
        System.out.println("The Total amount with GST = " +df2.format(rate));
        
        return GST;
    }
}